# BTC Vault Protocol - Multisig N-de-N

> Cofre não-custodial de Bitcoin. Deposite BTC, mova apenas com consenso total.

![Bitcoin](https://img.shields.io/badge/Bitcoin-F7931A?logo=bitcoin&logoColor=white)
![License](https://img.shields.io/badge/license-MIT-green)

## 🚀 Demo ao Vivo
Após deploy no Netlify/Vercel, seu site estará online.

## 🧠 Como funciona
1. **Criar Cofre**: Gera endereço P2WSH multisig n-de-n (ex: 3-de-3)
2. **Depositar**: Qualquer pessoa envia BTC para o endereço
3. **Sacar**: Cria PSBT e coleta TODAS as assinaturas

## 📁 Estrutura
```
/
├── index.html          # Site completo (demo + código)
├── contracts/
│   ├── WBTCVaultMultisig.sol  # Versão EVM para WBTC
│   └── btc-multisig.js        # Script Bitcoin puro
├── README.md
└── LICENSE
```

## 💻 Código Bitcoin Puro (btc-multisig.js)
```js
import * as bitcoin from 'bitcoinjs-lib';
import { ECPairFactory } from 'ecpair';
import * as ecc from 'tiny-secp256k1';

const ECPair = ECPairFactory(ecc);

export function createVault(pubkeysHex) {
  const pubkeys = pubkeysHex.map(hex => Buffer.from(hex, 'hex'));
  const p2ms = bitcoin.payments.p2ms({ m: pubkeys.length, pubkeys, network: bitcoin.networks.bitcoin });
  const p2wsh = bitcoin.payments.p2wsh({ redeem: p2ms, network: bitcoin.networks.bitcoin });
  return { address: p2wsh.address, redeem: p2ms, witness: p2wsh };
}

export function createSpendPsbt(vault, utxo, destination, signers) {
  const psbt = new bitcoin.Psbt({ network: bitcoin.networks.bitcoin });
  psbt.addInput({ hash: utxo.txid, index: utxo.vout, witnessUtxo: { script: vault.witness.output, value: utxo.value } });
  psbt.addOutput({ address: destination, value: utxo.value - 1000 });
  // Cada participante assina
  return psbt;
}
```

## 🔗 Solidity - WBTC Vault (EVM)
Veja em contracts/WBTCVaultMultisig.sol

## 🛠️ Rodar local
Basta abrir o index.html, não precisa de build.

## 📄 Licença
MIT - Pode usar, forkar, comercializar.
