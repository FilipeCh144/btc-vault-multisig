// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";

/// @title WBTC Vault Multisig N-de-N
/// @author Filipe Chaves
/// @notice Cofre que só libera WBTC com assinatura de TODOS os owners
contract WBTCVaultMultisig {
    IERC20 public immutable wbtc;
    address[] public owners;
    mapping(address => bool) public isOwner;
    uint256 public immutable requiredSignatures;

    mapping(bytes32 => mapping(address => bool)) public hasSigned;
    mapping(bytes32 => uint256) public signatureCount;

    event Deposited(address indexed from, uint256 amount);
    event WithdrawalProposed(bytes32 indexed txId, address to, uint256 amount);
    event Signed(bytes32 indexed txId, address indexed signer);
    event Executed(bytes32 indexed txId, address to, uint256 amount);

    constructor(address _wbtc, address[] memory _owners) {
        require(_owners.length >= 2, "min 2 owners");
        wbtc = IERC20(_wbtc);
        requiredSignatures = _owners.length;
        for(uint i=0; i<_owners.length; i++){
            require(_owners[i] != address(0), "zero");
            require(!isOwner[_owners[i]], "dup");
            isOwner[_owners[i]] = true;
            owners.push(_owners[i]);
        }
    }

    function deposit(uint256 amount) external {
        wbtc.transferFrom(msg.sender, address(this), amount);
        emit Deposited(msg.sender, amount);
    }

    function proposeWithdrawal(address to, uint256 amount, bytes32 txId) external {
        require(isOwner[msg.sender], "not owner");
        require(wbtc.balanceOf(address(this)) >= amount, "insufficient");
        emit WithdrawalProposed(txId, to, amount);
        _sign(txId);
    }

    function sign(bytes32 txId) external {
        require(isOwner[msg.sender], "not owner");
        _sign(txId);
    }

    function _sign(bytes32 txId) internal {
        require(!hasSigned[txId][msg.sender], "already signed");
        hasSigned[txId][msg.sender] = true;
        signatureCount[txId]++;
        emit Signed(txId, msg.sender);
    }

    function execute(address to, uint256 amount, bytes32 txId) external {
        require(signatureCount[txId] >= requiredSignatures, "need all sigs");
        signatureCount[txId] = 0; // prevent replay
        wbtc.transfer(to, amount);
        emit Executed(txId, to, amount);
    }
}
