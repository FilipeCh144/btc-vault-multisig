// btc-multisig.js - Uso real com bitcoinjs-lib
// npm install bitcoinjs-lib ecpair tiny-secp256k1
import * as bitcoin from 'bitcoinjs-lib';
import { ECPairFactory } from 'ecpair';
import * as ecc from 'tiny-secp256k1';
const ECPair = ECPairFactory(ecc);

export function createVault(pubkeysHex, network = bitcoin.networks.bitcoin) {
  const pubkeys = pubkeysHex.map(h => Buffer.from(h, 'hex')).sort((a,b) => a.compare(b));
  const p2ms = bitcoin.payments.p2ms({ m: pubkeys.length, pubkeys, network });
  const p2wsh = bitcoin.payments.p2wsh({ redeem: p2ms, network });
  return { address: p2wsh.address, p2ms, p2wsh };
}
